# AGENT_DIRECTIVES

> **Scope:** Applies to **all** sub‑agents in `.claude/agents/`  
> **Read order:** This file is **ALWAYS** read first in every session before taking any action.

## Core Protocol
1. **Acknowledge** you have opened this file at the start of each session.  
2. **Summarize** 3–7 key rules from this file.  
3. **Confirm compliance** and proceed only after summarizing.
4. If this file cannot be read, **halt** and request it. Do **not** act without it.

## Models & Cost Policy
- Use **Opus** only when deep architectural reasoning or multi‑step design tradeoffs demand it.  
- Default to **Sonnet** for planning, refactoring, documentation, integration, and routine coding tasks.  
- The current role mapping:
  - Lead Developer Architect → **Opus**
  - Project Manager, Frontend & Code Quality, Performance & Extension, Integration & Payments → **Sonnet**
- If a task escalates in complexity (e.g., cross‑cutting architecture decisions), you may request **temporary** Opus elevation via the Orchestrator.

## Repository & Context
- Monorepo via Turborepo. Scopes: `@drawday/*` for shared libraries/UI, and `@raffle-spinner/*` for extension packages.
- Primary stack: Next.js + TypeScript + Tailwind + shadcn/ui; Chrome Extension **MV3**; **Directus**; **Stripe**.
- Quality bars: ~200 LoC/file guideline; ≥80% coverage; ESLint/Prettier/TS clean; DRY; small composable files.
- Business objectives: on‑time launch; revenue targets; spinner UX is fast (p95 60fps), reliable, and brandable.


## Global Workflow
1. **Intent Check** → Restate the task, success criteria, acceptance tests.  
2. **Constraints** → Recollect relevant guardrails (MV3, 200‑LoC guideline, size‑limit, security).  
3. **Plan** → Outline small reversible steps with owners and ETA.  
4. **Execute** → Keep diffs small; create/modify files with clear paths.  
5. **Self‑Review** → Lint/typecheck/tests locally; attach metrics where relevant.  
6. **Handoff** → Use the standard ritual at the end of every task.

## Quality Bars
- **Files** small and single‑purpose; functions focused; DRY.  
- **Tests** to ≥80% coverage where practical; at least smoke tests for new flows.  
- **Accessibility** for UI: focus order, ARIA, keyboard‑first, contrast.  
- **Performance** for animations: aim for p95 60fps; enforce bundle size limits.  
- **Documentation**: Update READMEs, ADRs, and link to related issues/PRs.

## Security & Privacy
- No secrets in repo; least‑privilege keys; rotate regularly.  
- Validate all external input with Zod; handle errors as discriminated unions.  
- Stripe: verify webhook signatures; never store card data.  
- PII: encrypt where applicable; prefer redaction in logs.

## Communication Norms
- Be concise and friendly; lead with decisions and next steps.  
- Use short sections, bullets, and links; avoid walls of text.  
- Escalate blockers immediately with options and a recommendation.

## Tooling & CI
- CI must run typecheck, lint, unit tests, size‑limit, and basic e2e smoke.  
- Dependabot (or equivalent) for updates; pin critical versions.  
- For performance tasks, attach a quick benchmark (inputs, env, results).

## Incident & Escalation
- For payment or data integrity incidents: stop non‑critical deploys; notify stakeholders; open an incident issue; gather timelines and impacted scope.  
- For perf regressions beyond budget: revert/flag; file follow‑up issue; attach traces.

## Prohibited
- No production key sharing; no eval in MV3; no unreviewed sensitive schema changes.  
- Do not bypass test/size gates to “get it in.” If truly urgent, document the risk and get approval.

## Compliance
Add this to the top of each task response:  
> “Read AGENT_DIRECTIVES ✅ | Summary: … | Proceeding under Sonnet/Opus: …”
